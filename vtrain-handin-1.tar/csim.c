/* Name: Viren Velacheri  UTEid: vv6898
This file basically runs a virtual cache simulation based off a trace file
as well as the other parameters of the cache like the associativity, number of
set bits, etc. After reading through all the given addresses in file and
modifying cache as necessary, a summary is printed, telling how many total hits,
evictions, and misses were there. */
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>

// This is the list of arguments in order that it looks through.
const char CACHE_PARAMS[] = "s:E:b:t:v";
// a constant that is used for both optarg and filePath checks. Did this
// because I treated it as a magic value that is used in multiple methods.
#define NOT_FOUND NULL
/* This is the structure for my cache. Basically represents what is there in a
single line. In addition to the tag and valid bits, also have a relative
timeStamp variables used for the LRU policy.*/
typedef struct {
  unsigned long tag;
  int timeStamp;
  bool valid;
} cacheLine;

//These variables are all my global variables as they are used in multiple
// methods and hence can't just be created locally.
cacheLine *cache;
int setBits = 0;
int numLines = 0;
int blockBits = 0;
int currTime = 0;
int numSets = 0;
int totalHits, totalMisses, totalEvictions = 0;
char *trace;

/* This method gets the values of the arguments passed in. It essentially is
what initializes the parameters for the cache that are stored in my global
variables. */
void getInputs(int argc, char *argv[]) {
  int opt = getopt(argc, argv, CACHE_PARAMS);
  int param = 0;
  int const NO_OPTIONS = -1;
  while(opt != NO_OPTIONS) {
    if(optarg != NULL) {
      param = atoi(optarg);
    }
    // This is done to initialize all the necessary cache parameters I need
    // like the number of set bits, block bits, associativity, and even the
    // trace file itself.
    switch(opt) {
      case 's':
      setBits = param;
      break;
      case 'E':
      numLines = param;
      break;
      case 'b':
      blockBits = param;
      break;
      case 't':
      trace = optarg;
      break;
      default:
      break;
    }
    opt = getopt(argc, argv, CACHE_PARAMS);
  }
}

/* This method is used for updating the cache based off the given address read
in. After the update, it is categorized as either a hit or a miss and/or
eviction and the necessary category is updated */
void runningSimulation(unsigned long address) {
  // I extract the tag part of address for use in trying to identify the line
  // in set if there. Get the set index and use that to find first line in
  // that set so that I use that as a starting point for locating address
  // within set. The relative time is increased for each address read for the
  // LRU policy.
  unsigned long addressTag = address >> (blockBits + setBits);
  int setIndex = address >> blockBits & (numSets - 1);
  int setLine = numLines * setIndex;
  currTime++;
  int recordedTime = currTime;
  // this below variables is used for determining in cache exactly the address
  // being inserted.
  int insertSpot = setLine;
  int line = 0; // used like a counter for going through selected set.
  // Use below bool for when a hit is found so that we can exit immediately.
  // likewise for when we find an invalid line.
  bool hitFound = false;
  bool replacementFound = false;
  while(!replacementFound && !hitFound && line < numLines) {
    if(cache[setLine + line].valid) {
      if(cache[setLine + line].tag == addressTag) {
        hitFound = true;
        cache[setLine + line].timeStamp = currTime;
        totalHits++;
      } else if(cache[setLine + line].timeStamp < recordedTime) {
        recordedTime = cache[setLine + line].timeStamp;
        insertSpot = setLine + line;
      }
    } else {
      insertSpot = setLine + line;
      replacementFound = true;
      recordedTime = currTime;
    }
    line++;
  }
  //Since there was no hit, has to be a miss. Then if the recorded time doesn't
  // match up with the current time, that indicates that cache is full within
  // set and hence by LRU we evict the least recently used line in the set.
  if(!hitFound){
    totalMisses++;
    if(recordedTime != currTime) {
      totalEvictions++;
    }
    // Sets respective fields for address inserted into cache.
    cache[insertSpot].valid = true;
    cache[insertSpot].timeStamp = currTime;
    cache[insertSpot].tag = addressTag;
  }
}

/* This is the main where given the arguments/input, the cache simulation is
run for the file/trace and it essentially goes until there are no more
addresses to read in from the file. */
int main(int argc, char *argv[]) {
  // Below is variable used for path of file and the other three below are
  // the formmatted inputs that are read from the stream/file oobject.
  FILE *filePath;
  char command;
  unsigned long address;
  int size;
  const int NUM_ARGS = 3; // number of formatted arguments
  getInputs(argc, argv);
  numSets = 1 << setBits;
  // allocating the size of cache amount of memory based off forula:
  // C = S * E * B.
  cache = (cacheLine *) malloc(sizeof(cacheLine) * numLines * numSets);
  filePath = fopen(trace, "r"); // gets file
  // This makes sure that file path is legit and not wrong. May not be
  // necessary in this case to have
  if(filePath != NOT_FOUND) {
    // Goes until the number of formatted inputs isn't three
    while(fscanf(filePath, " %c %lx,%d", &command, &address, &size) == NUM_ARGS){
      switch(command) {
        // for case M since have to run two simulations, just run once and
        // then let it fall through L which has a single simulation before
        // stopping. Default case covers command I as well so felt it would
        // have been repetitive to create a case for command I as well since
        // we were not doing anything like in default.
        case 'M':
        runningSimulation(address);
        case 'L':
        runningSimulation(address);
        break;
        case 'S':
        runningSimulation(address);
        break;
        default:
        break;
      }
    }
  }
  printSummary(totalHits, totalMisses, totalEvictions);
  // below line closes file object/stream
  fclose(filePath);
  free(cache); // memory is freed at end since program is done
  return 0; // the default value returned is 0 as per the standard.
}
